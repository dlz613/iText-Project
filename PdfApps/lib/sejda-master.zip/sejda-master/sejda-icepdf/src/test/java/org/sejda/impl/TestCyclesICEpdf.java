package org.sejda.impl;

import org.sejda.TestCycles;


/**
 * Tests for cycles.
 * 
 * @author Andrea Vacondio
 * 
 */
public class TestCyclesICEpdf extends TestCycles {

    // inherited tests

}
