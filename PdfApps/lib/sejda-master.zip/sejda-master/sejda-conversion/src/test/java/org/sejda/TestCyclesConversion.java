package org.sejda;


/**
 * Test for cycles.
 * 
 * @author Andrea Vacondio
 * 
 */
public class TestCyclesConversion extends TestCycles {

    // inherited tests

}
