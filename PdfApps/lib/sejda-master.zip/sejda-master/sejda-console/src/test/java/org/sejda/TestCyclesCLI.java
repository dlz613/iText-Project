package org.sejda;


/**
 * Test for cycles.
 * 
 * @author Andrea Vacondio
 * 
 */
public class TestCyclesCLI extends TestCycles {

    // inherited tests

}
